"""Rebuild the numeric TeX tables and simulated gait curves from the supplement."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

anc = Path(__file__).resolve().parent
paper = anc.parent
tables = paper / "tables"
tables.mkdir(exist_ok=True)
widths = [1024, 1440, 2048, 2880, 4096]
sizes = ["8M", "16M", "31M", "60M", "120M"]
parents = dict(zip(widths, sizes))
branches = [2500, 5000, 10000, 20000]
budgets = ["0.360", "0.721", "1.442", "2.884"]
keys = ["joint_q_rmse_rad", "joint_dq_rmse_rad_s", "gyro_rmse_rad_s", "up_vector_mean_angle_deg"]
digits = [4, 3, 3, 2]


def records(name):
    with (anc / name).open() as stream:
        return list(csv.DictReader(stream))


def save_rows(name, rows):
    lines = [row if isinstance(row, str) else " & ".join(row) + r" \\" for row in rows]
    (tables / (name + ".tex")).write_text("\n".join(lines) + "\n")


def format_scores(values):
    return [f"{v:.{n}f}" for v, n in zip(values, digits)]


panel_scores = records("go2-adapted.csv") + records("go2-core.csv")
case_scores = {(r["case"], r["model"]): r for r in panel_scores}
assert len(case_scores) == len(panel_scores) == 687
with np.load(anc / "go2-panel.npz") as data:
    metadata = dict(zip(data["ids"], json.loads(data["metadata"].item())))
stock = [k for k, v in metadata.items() if v.get("physical_controller") == "Unitree SDK2 SportClient"]
fast = [k for k in stock if metadata[k].get("target_speed_m_s") == 0.5]
handset = [k for k, v in metadata.items() if v.get("physical_controller") == "handset"]
assert (len(stock), len(fast), len(handset)) == (9, 4, 2)


def pooled(model, cases):
    x = np.array([[float(case_scores[c, model][k]) for k in keys] for c in cases])
    return [*np.sqrt(np.mean(x[:, :3] ** 2, axis=0)), x[:, 3].mean()]


baselines = [("Persistence", "persistence"), ("MuJoCo, nominal", "nominal_mujoco"),
             ("MuJoCo, recorded gains", "matched_mujoco")]
adapted = [(name, f"adapted_w{w}") for w, name in parents.items()]
extra = [("13M GRU, cosine 8k", "gru_13m_cosine8k"),
         ("120M GRU, WSD 5k", "gru_120m_wsd5000"),
         ("120M GRU, WSD 10k", "gru_120m_wsd10000")]
extra += [(f"Sensor GRU, seed {s}", f"swm_sensor_s{s}") for s in (0, 1)]
extra += [(f"Pilot, seed {s}, {n} worlds", f"proprio_flat_pilot_seed{s}_proprio_{n}worlds")
          for s in (0, 1) for n in (8, 64)]
zeros = [(f"{name}, {b}B", f"zero_w{w}_b{branch}")
         for w, name in parents.items() for b, branch in zip(budgets, branches)]
assert {m for _, m in baselines + adapted + extra + zeros} == {r["model"] for r in panel_scores}


def hardware_rows(models):
    return [[name, *format_scores(pooled(m, stock)), f"{pooled(m, fast)[0]:.4f}",
             f"{pooled(m, handset)[0]:.4f}"] for name, m in models]


save_rows("hardware", hardware_rows(baselines) + [r"\midrule"] + hardware_rows(adapted))
save_rows("other", hardware_rows(zeros) + [r"\midrule"] + hardware_rows(extra))

training = records("go2-training.csv")
transfer = []
for w, name in parents.items():
    run = "proprio_120m_transfer_flat" if w == 4096 else f"proprio_transfer_w{w}_flat"
    pair = sorted((r for r in training if r["experiment"] == run), key=lambda r: int(r["updates"]))
    assert [int(r["updates"]) for r in pair] == [0, 32]
    transfer.append([name] + [f"{float(r['validation_' + k]):.3f}"
                              for k in ["one_step", "roll_1s", "roll_3s"] for r in pair])
save_rows("transfer", transfer)
save_rows("pilots", [[r["experiment"][-1], r["worlds"]] +
                      [f"{float(r['validation_' + k]):.3f}" for k in ["one_step", "roll_1s", "roll_3s"]]
                     for r in training if "pilot" in r["experiment"] and r["updates"] == "600"])

named_rows = records("go2-named-modes.csv")
named = {(r["sdk_request"], float(r["horizon_s"]), r["model"]): r for r in named_rows}
drives = baselines[:2] + [("MuJoCo, full drive", "published_drive_mujoco")]
for output, seconds in [("named", [1., 1.]), ("named-full", [1.3, 2.])]:
    scores = []
    for name, m in drives + adapted:
        row = [name]
        for gait, t in zip(["static-walk", "trot-run"], seconds):
            obs = named[gait, t, m]
            row.extend(format_scores([float(obs[k]) for k in keys]))
        scores.append(row)
    save_rows(output, scores)
sweep = json.loads((anc / "scaling-data.json").read_text())["checkpoints"]
grid = []
for a in sorted(sweep, key=lambda a: (a["width"], a["updates"])):
    if grid and a["width"] != last:
        grid.append(r"\addlinespace[2pt]")
    grid.append([f"{a['N']/1e6:.2f}", f"{a['D_transitions']/1e9:.3f}"] +
                [f"{np.sqrt(np.mean(a['per_shard_mse'][k])):.3f}"
                 for k in ["onestep", "roll_1s", "roll_3s"]])
    last = a["width"]
save_rows("scaling-grid", grid)
gaits = records("go2-t2-gaits.csv")
save_rows("gaits", [[r["gait"].replace("_", " ").capitalize()] + format_scores([float(r[k]) for k in keys])
                    for r in gaits])
filmed = records("go2-filmed-scores.csv")
save_rows("filmed", [[("120M adapted" if r["model"] == "World model" else r["model"])] +
                     format_scores([float(r[k]) for k in keys]) for r in filmed])

# A shared vertical scale within each row preserves across-gait differences.
# Log scales keep the small errors visible alongside the pronk turnover.
curves = records("go2-t2-curves.csv")
fig, axes = plt.subplots(3, 2, figsize=(6.5, 5.3), sharex=True, sharey="row",
                         layout="constrained")
colors = ["#005582", "#B25016", "#20805D", "#78467B"]
for j, selected in enumerate([gaits[:4], gaits[4:]]):
    for g, color in zip(selected, colors):
        case = g["case"]
        trace = [r for r in curves if r["case"] == case]
        assert len(trace) == 150
        t = [float(r["seconds"]) for r in trace]
        for i, k in enumerate(["joint_q_rmse_rad", "gyro_rmse_rad_s", "up_angle_deg"]):
            y = np.array([float(r[k]) for r in trace])
            axes[i, j].plot(t, np.ma.masked_less_equal(y, 0), color=color, lw=.85,
                            label=case.replace("_", " ").capitalize())
    axes[0, j].legend(loc="lower left", bbox_to_anchor=(0, 1.02, 1, .3), mode="expand",
                      ncol=2, borderaxespad=0, frameon=False, fontsize=8)
for row, label in zip(axes, ["Joint angle (rad)", "Gyro (rad/s)", "Body up (deg)"]):
    row[0].set_ylabel(label, fontsize=9)
    for ax in row:
        ax.set_yscale("log")
        ax.grid(axis="y", alpha=.25)
        ax.tick_params(labelsize=8)
        ax.spines[["top", "right"]].set_visible(False)
for ax in axes[-1]:
    ax.set(xlabel="Forecast time (s)", xlim=(0, 3))
fig.savefig(paper / "figures" / "gait-curves.pdf")

# Physical errors use the full interval of recorded drive commands.
film_curves = records("go2-filmed-curves.csv")
fig, axes = plt.subplots(3, 1, figsize=(6.4, 4.4), sharex=True, layout="constrained")
for model, label, color, style in [
    ("MuJoCo nominal", "MuJoCo, nominal", "#999999", "-"),
    ("MuJoCo recorded gains", "MuJoCo, recorded gains", "#B25016", "--"),
    ("World model", "120M adapted", "#005582", "-"),
]:
    trace = [r for r in film_curves if r["model"] == model]
    assert len(trace) == 254
    t = [float(r["seconds"]) for r in trace]
    for ax, key in zip(axes, ["joint_q_rmse_rad", "gyro_rmse_rad_s", "up_angle_deg"]):
        ax.plot(t, [float(r[key]) for r in trace], color=color, ls=style, lw=1, label=label)
for ax, label in zip(axes, ["Joint angle (rad)", "Gyro (rad/s)", "Body up (deg)"]):
    ax.set_ylabel(label, fontsize=9)
    ax.grid(axis="y", alpha=.25)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_ylim(bottom=0)
axes[0].legend(loc="lower center", bbox_to_anchor=(.5, 1), ncol=3, frameon=False, fontsize=8)
axes[-1].set(xlabel="Seconds from physical walk cue", xlim=(0, 5.08))
fig.savefig(paper / "figures" / "filmed-sensors.pdf")
