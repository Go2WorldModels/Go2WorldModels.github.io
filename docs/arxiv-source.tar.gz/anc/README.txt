Numerical supplement to Scaling Quadruped World Models
Ramakrishna Kompella, Gödel Machines

Run from the extracted submission directory:
  python3 anc/scaling.py
  python3 anc/transfer_figure.py
NumPy, SciPy, and Matplotlib are required for analysis. The TeX build uses the
supplied vector figures directly. Add --refit-original to scaling.py to rerun
the archival 243-start fit in addition to the centered sensitivity analysis.

scaling-data.json contains the size, budget, logged compute estimate,
retained-update proxy, and per-shard MSEs of the 20 checkpoints. Shard order
is shared across checkpoints, enabling paired comparisons. The original fit
parameters use raw counts; the manuscript reports equivalent reference units.

transfer-errors.npz contains four arrays shaped (32 worlds, 150 time steps).
Entries are the channel-average squared errors after standardization, with
shared world order. The world and start arrays identify the segment of each
flat-ground validation world. The data support reproduction of the reported
evaluation statistics. Retraining requires the original trajectory corpus.

go2-panel.npz contains the fixed 11 hardware and eight simulation cases (ids and
domain), their 201 readings and 200 12-joint targets, case metadata and three
reference predictions for hardware. The first 51 readings and 50 targets are
context. go2-core.csv and go2-adapted.csv give each model's per-case errors.
The main hardware table uses the nine SDK case IDs in panel metadata; the two handset cases are supplemental. Run python3 anc/hardware_figure.py to rebuild its paired plot. Pool equal-length case RMSEs in quadrature; average the case mean up angles.
Branch suffixes 2500, 5000, 10000 and 20000 denote the four increasing exposure
budgets. Widths 1024, 1440, 2048, 2880, 4096 correspond to the 8, 16, 31, 60,
120M parent sizes. zero_ denotes zero-scan transfer. adapted_ denotes matched
32-update projection adaptation. The extra archived models are supplemental
comparators; privileged full-state predictors require other inputs.
go2-filmed-scores.csv gives the filmed 5.08 s replay. go2-camera-audit.json
contains the endpoint checks and grid correspondences. The T2 gait traces have
a MuJoCo reference. Hardware case IDs refer to a single physical Go2.

go2-named-modes.csv and go2-named-modes.npz cover two later SDK requests
(StaticWalk and TrotRun). The common horizon is 1.00 s. Full horizons are
1.30 and 2.00 s, respectively. Each case includes the measured history and
targets, initial quaternion, aligned drive signals, and all forecast sequences.
Score forecast row 0 against observation row 51. published_drive_mujoco
replays q, dq target, kp, kd and feedforward; nominal_mujoco uses q only
and default gains. These short recordings form a separate two-case table.

go2-results.html is a self-contained, offline reader for the complete results
index. It includes all 687 fixed-panel model-case scores, 32 named-mode scores,
and the original run diagnostics at their logged horizons. go2-training.csv
holds all 38 logged training/validation records for projection adaptation and
scratch pilots. go2-t2-curves.csv gives the 50 Hz gait traces in the appendix.
Run python3 anc/replay_tables.py to rebuild the numerical TeX table inputs
and gait and filmed-walk figures. go2-filmed-curves.csv contains their physical\ncounterpart over 254 ticks of the filmed walk. The before and settled PNGs are original iPhone stills from
20261122-180625-ueuixi21. See go2-camera-audit.json for the projection audit.
