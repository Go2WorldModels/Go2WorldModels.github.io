"""Regenerate the transfer figure and its paired uncertainty estimates from the per-world scores."""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

root = Path(__file__).resolve().parents[1]
data = np.load(root / 'anc' / 'transfer-errors.npz')
indices = np.random.default_rng(2026).integers(0, len(data['world']), (10000, len(data['world'])))
curves = {}
for name in ('adapted', 'initial', 'scan', 'persistence'):
    mse = data[name].astype(np.float64)
    curves[name] = np.sqrt(mse.mean(axis=0))
    endpoints = mse[:, [49, 149]]
    print(name, '1s and 3s:', curves[name][[49, 149]])
    print('95% world-bootstrap intervals:', np.quantile(np.sqrt(endpoints[indices].mean(axis=1)), [.025, .975], axis=0))
for other in ('initial', 'persistence'):
    samples = [np.sqrt(data[k][:, [49, 149]].astype(np.float64)[indices].mean(axis=1)) for k in ('adapted', other)]
    print('adapted minus', other, np.quantile(samples[0] - samples[1], [.025, .975], axis=0))

plt.rcParams.update({'font.size': 9, 'pdf.fonttype': 42, 'axes.spines.top': False, 'axes.spines.right': False})
fig, ax = plt.subplots(figsize=(6.3, 2.85))
h = np.arange(1, 151) / 50
for key, label, color, style in [
    ('persistence', 'Last reading', '#767676', ':'),
    ('initial', 'Proprioceptive, before adaptation', '#C46E25', '--'),
    ('adapted', 'Proprioceptive, after adaptation', '#176491', '-'),
    ('scan', 'Recorded terrain scan', '#28734D', '-.')]:
    ax.plot(h, curves[key], color=color, linestyle=style, linewidth=1.8, label=label)
    ax.plot(h[[49,149]], curves[key][[49,149]], 'o', color=color, markersize=3.2, clip_on=False)
ax.grid(axis='y', linewidth=.5, alpha=.35)
ax.set(xlabel='Time from forecast origin (s)', ylabel='Normalized rollout RMSE', xlim=(0, 3), ylim=(0, None))
ax.legend(frameon=False, ncol=2, loc='lower center', bbox_to_anchor=(.5, 1), fontsize=8)
fig.tight_layout()
fig.savefig(root / 'figures' / 'proprio-horizon.pdf', bbox_inches='tight')
