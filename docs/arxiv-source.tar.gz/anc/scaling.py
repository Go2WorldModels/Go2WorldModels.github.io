"""Render the paper's scaling figure and reproduce the fit sensitivity checks.

Run with Python 3, NumPy, SciPy, and Matplotlib. Pass --refit-original for
the original 243-start search (optimizer versions can change the optimum).
Input scaling-data.json contains
the 96 per-shard MSEs per metric per checkpoint, the logged compute estimate,
and the original all-grid point fits. No checkpoint weights are needed.
"""
import argparse
import json
from itertools import product
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import least_squares, minimize
from scipy.special import logsumexp

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / "scaling-data.json").read_text())
ROWS = DATA["checkpoints"]
METRICS = ("onestep", "roll_1s", "roll_3s")
N = np.array([r["N"] for r in ROWS], dtype=float)
D = np.array([r["D_transitions"] for r in ROWS], dtype=float)
LOGGED_FLOPS = np.array([r["flops"] for r in ROWS])
# The historical proxy charged the full step network for history. The GRU
# context encoder, with its own 66,048 weights and biases, processes it.
FLOPS = 12*N*D + (LOGGED_FLOPS - 12*N*D) * (66_048 / N)
RETAINED = np.array([r["retained_plus_scheduled_decay"] * 131072 for r in ROWS])
MSE = {k: np.array([r["per_shard_mse"][k] for r in ROWS]) for k in METRICS}
LOSS = {k: np.sqrt(v.mean(axis=1)) for k, v in MSE.items()}
WIDTHS, BUDGETS = np.unique(N), np.unique(D)
UNSTABLE = (N == WIDTHS[0]) & (D == BUDGETS[1])


def predict(p, n, d):
    return p[0] + p[1] * (n / 3e7)**(-p[3]) + p[2] * (d / 1e9)**(-p[4])


def scaled_coefficients(archived):
    f = archived
    return np.array([f["E"], f["A"] / 3e7**f["alpha"], f["B"] / 1e9**f["beta"],
                     f["alpha"], f["beta"]])


def refit_original(metric):
    """Rerun the original archive's log-amplitude, multistart L-BFGS search."""
    # Original scorer sorted paths lexicographically (branch_10000 precedes
    # branch_2500). Retain order to limit finite-difference roundoff changes.
    order = sorted(range(len(ROWS)), key=lambda i: (ROWS[i]["width"],
                   str(round(ROWS[i]["updates"] / 1.1))))
    ln, ld = np.log(N[order]), np.log(D[order])
    ly = np.log(LOSS[metric][order])

    def objective(p):
        terms = np.stack((p[0] - p[3] * ln, p[1] - p[4] * ld, np.full_like(ln, p[2])))
        r = abs(logsumexp(terms, axis=0) - ly)
        return np.where(r < .001, .5*r*r, .001*(r-.0005)).sum()

    bounds = [(-10, 40), (-10, 40), (-8, 2), (0, 2), (0, 2)]
    seeds = product((0, 5, 10), (0, 5, 10), (.1, .3, .6), (.1, .3, .6), (-3, -2, -1))
    fits = (minimize(objective, [a, b, e, alpha, beta], method="L-BFGS-B", bounds=bounds)
            for a, b, alpha, beta, e in seeds)
    best = min(fits, key=lambda f: f.fun).x
    return dict(A=np.exp(best[0]), B=np.exp(best[1]), E=np.exp(best[2]),
                alpha=best[3], beta=best[4])


def refit(mask, loss, d):
    """Robust log-error minimization with positive components and bounded exponents.

    Reference units 30M and 1B improve numerical conditioning. All starting
    values use only the included points. The floor approaches zero at a small
    positive numerical bound. Convergence is checked from multiple starts.
    """
    n, d, y = N[mask], d[mask], loss[mask]
    log_n, log_d = np.log(n / 3e7), np.log(d / 1e9)

    def residual(p):
        return np.log(predict(p, n, d)) - np.log(y)

    def jac(p):
        q, s = np.exp(-p[3]*log_n), np.exp(-p[4]*log_d)
        deriv = np.stack([np.ones_like(q), q, s, -p[1]*q*log_n, -p[2]*s*log_d], axis=1)
        return deriv / predict(p, n, d)[:, None]

    starts = [[.2, .01, .15, .8, .4]]
    for a in (0.1, 0.5, 1.5):
        for b in (0.15, 0.6):
            starts.append([min(y)*.4, .03, .1, a, b])
    fits = [least_squares(residual, p, jac=jac, bounds=([1e-6]*3+[0, 0], [5, 5, 5, 2, 2]),
                          loss="huber", f_scale=.001, max_nfev=3000,
                          gtol=1e-12, ftol=1e-12, xtol=1e-12) for p in starts]
    return min(fits, key=lambda f: f.cost).x


def diagnostics():
    for metric in METRICS:
        y = LOSS[metric]
        p = scaled_coefficients(DATA["archived_fits"][metric])
        rel_err = predict(p, N, D)/y-1
        print(metric, "archived [E, A_30M, B_1B, alpha, beta]", p,
              "median/max abs % error", 100*np.median(abs(rel_err)), 100*max(abs(rel_err)))
        if metric == "roll_3s":
            for d, mask, name in [(D, N > 0, "all checkpoints"), (D, ~UNSTABLE, "omit spike"),
                                  (RETAINED, ~UNSTABLE, "retained exposure")]:
                pp = refit(mask, y, d)
                print(name, pp)
            held = D < BUDGETS[-1]
            pp = refit(held, y, D)
            yy = predict(pp, N[~held], D[~held])
            print("last budget held out", pp, yy, "observed", y[~held], "relative errors", yy/y[~held]-1)
            print("width leave-outs (alpha, beta)")
            for n in WIDTHS:
                print(n, refit(N != n, y, D)[-2:])

    y = MSE["roll_3s"]
    rng = np.random.default_rng(2026)
    ids = rng.integers(y.shape[1], size=(10000, y.shape[1]))
    for i,j in [(-2,-1), (16,7)]:
        before, after = np.sqrt(y[i,ids].mean(axis=1)), np.sqrt(y[j,ids].mean(axis=1))
        print("paired", N[i], D[i], N[j], D[j], np.quantile(before-after,[.025,.975]),
              (y[i] > y[j]).sum(), "FLOPs", FLOPS[i], FLOPS[j])


def render():
    plt.rcParams.update({"font.size": 8.6, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "axes.labelcolor": "#18232c", "axes.edgecolor": "#8f999f",
                         "xtick.color": "#33424a", "ytick.color": "#33424a"})
    fig, (ax, bx) = plt.subplots(1, 2, figsize=(7.15, 3.45))
    fig.subplots_adjust(left=.086, right=.985, top=.79, bottom=.19, wspace=.30)
    loss = LOSS["roll_3s"]
    colors = ["#0072B2", "#C76C13", "#008369", "#A24483", "#31373C"]
    markers = ["o", "s", "^", "D", "v"]
    coef = scaled_coefficients(DATA["archived_fits"]["roll_3s"])
    x = np.geomspace(D.min(), D.max(), 300)
    for n, c, m in zip(WIDTHS, colors, markers):
        sel = N == n
        label = f"{round(n/1e6)}M"
        ax.plot(x/1e9, predict(coef, n, x), color=c, linewidth=1.25)
        ax.scatter(D[sel]/1e9, loss[sel], facecolor=c, edgecolor="white", linewidth=.55,
                   marker=m, s=32, zorder=3, label=label)
        bx.scatter(FLOPS[sel]/1e18, loss[sel], color=c, edgecolor="white", linewidth=.55, marker=m, s=32, zorder=3)
    for panel in (ax, bx):
        panel.set_xscale("log")
        panel.grid(axis="y", alpha=.24, lw=.6)
        panel.set_ylim(.335,.763)
        panel.tick_params(length=2)
        panel.minorticks_off()
    ax.annotate("unstable decay", xy=(D[UNSTABLE][0]/1e9, loss[UNSTABLE][0]), xytext=(.46,.676),
                fontsize=7.2, color="#33424a", arrowprops={"arrowstyle":"-", "color":"#70808b", "lw":.7})
    ax.set_xticks(BUDGETS/1e9, [f"{d/1e9:.2f}" for d in BUDGETS])
    ax.set_ylabel("3 s endpoint NRMSE")
    ax.set_xlabel("Sampled transitions (billions)")
    ax.set_title("(a)  Size and exposure", loc="left", fontsize=9.3)
    bx.set_title("(b)  Training compute", loc="left", fontsize=9.3)
    bx.set_xlabel(r"Encoder-adjusted FLOP proxy ($10^{18}$)")
    bx.set_xticks([.1,.3,1,3], [".1",".3","1","3"])
    order = np.argsort(FLOPS)
    best, lower = np.inf, []
    for i in order:
        if loss[i] < best:
            lower.append(i)
            best = loss[i]
    bx.step(FLOPS[lower]/1e18, loss[lower], where="post", lw=1, color="#737f85", zorder=1)
    bx.annotate("16M, long", xy=(FLOPS[7]/1e18,loss[7]), xytext=(.14,.345),
                fontsize=7, arrowprops={"arrowstyle":"-", "color":"#70808b", "lw":.7})
    bx.annotate("120M, short", xy=(FLOPS[16]/1e18,loss[16]), xytext=(1.0,.58),
                fontsize=7, arrowprops={"arrowstyle":"-", "color":"#70808b", "lw":.7})
    fig.legend(*ax.get_legend_handles_labels(), loc="upper center", ncol=5, frameon=False,
               handletextpad=.12, columnspacing=1.2, bbox_to_anchor=(.5,1.0))
    out = HERE.parent / "figures" / "scaling.pdf"
    out.parent.mkdir(exist_ok=True)
    fig.savefig(out)
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refit-original", action="store_true")
    args = parser.parse_args()
    if args.refit_original:
        for metric in METRICS:
            print(metric, "original search", refit_original(metric))
    diagnostics()
    render()
