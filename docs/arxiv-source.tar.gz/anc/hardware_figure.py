"""Rebuild the paired physical joint-error plot from the numerical supplement."""
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

here = Path(__file__).resolve().parent
with (here/"go2-adapted.csv").open() as f:
    adapted = list(csv.DictReader(f))
with (here/"go2-core.csv").open() as f:
    core = list(csv.DictReader(f))
ticks = ["8M","16M","31M","60M","120M","MuJoCo\nrecorded gains"]
labels = ["adapted_w"+str(w) for w in (1024,1440,2048,2880,4096)]+["matched_mujoco"]
with np.load(here/"go2-panel.npz") as panel:
    cases = [case for case, info in zip(panel["ids"], json.loads(str(panel["metadata"])))
             if info.get("physical_controller") == "Unitree SDK2 SportClient"]
rows = {(r["case"],r["model"]):r for r in adapted+core if r["domain"]=="hardware"}
values = np.array([[float(rows[c,k]["joint_q_rmse_rad"]) for k in labels] for c in cases])
fig, ax = plt.subplots(figsize=(6.6,2.6),layout="constrained")
ax.plot(np.arange(len(labels)),values.T,color="#9eacb5",alpha=.65,lw=.8)
ax.plot(np.arange(len(labels)),np.sqrt(np.mean(values**2,axis=0)),"o-",color="#005982",label="Pooled over 9 SDK trials")
ax.set(xticks=np.arange(len(labels)),xticklabels=ticks,ylabel="Joint-angle RMSE (rad)",ylim=(0,None))
ax.grid(axis="y",alpha=.2)
ax.legend(frameon=False)
fig.savefig(here.parent/"figures/hardware-joints.pdf")
